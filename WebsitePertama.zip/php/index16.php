<html>
     <head><title>Form</title></head>
     <body background="anonym3.jpg">
	 <center>
          <form action="index17.php" method="post">
		  <table>
<tr id="header">
<h2><font color="white">Isi Biodata!!!</font></h2>
</tr>
            <p>
<font color="white">Nama</font>            : <input type="text" name="nama"/></p>
<p>
<font color="white">Alamat</font>          : <input type="text" name="alamat"/></p>
<p>
<font color="white">Jenis Kelamin</font>   :</p>
<input type="radio" name="sex" value="Laki-laki"/><font color="white">Laki - laki</font>
                <input type="radio" name="sex" value="Perempuan"/><font color="white">Perempuan</font>
            <p>
<font color="white">Pekerjaan</font>       :</p>
<select name="pekerjaan">
                <option value="pelajar">Pelajar</option>
                <option value="Youtuber">Youtuber</option>
                <option value="Gamers">Gaming</option>
                </select>
            <p>
<font color="white">Hobby</font>           :</p>
<input type="checkbox" name="hobby" value="Sepakbola"/><font color="white">Game</font>
              <input type="checkbox" name="hobby" value="Main Komputer"/><font color="white">Main Komputer</font>
              <input type="checkbox" name="hobby" value="Tidur"/><font color="white">Tidur</font>
			  <input type="checkbox" name="hobby" value="Ngopi"/><font color="white">Ngopi</font>
            <p>
<input type="submit" value="kirim data"/>
              <input type="reset" value="ulangi"/></p>
</table>  
</form>
</center>
</body>
</html>
