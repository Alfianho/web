<html>
     <head><title>Form</title></head>
     <body background="anonymous.jpg">
	 <center>
<form action="index16.php" method="get">
<br>
<br>
<br>
<br>
<table>
<tr id="header">
<h2><font color="red">LOGIN!!!</font></h2>
</tr>
<p><font color="red">Nama</font>     :  <input  type="text"   name="nama"></input><br/>
<p><font color="red">Password</font> :  <input  type=”password” nama=”password”/>
<tr>
 <input type="submit" name="submit" value="Login"></input>
 <input type="reset" value="Reset"/></p>
   </table>
 </form>
 </center>
</body>
</html>
