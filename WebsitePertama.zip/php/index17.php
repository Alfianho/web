<html>
<head>
<title>Document</title>
</head>
<body background="anonym2.jpg">
<center>
<br>
<br>
<br>
<?php
$nama     =$_POST['nama'];
$alamat   =$_POST['alamat'];
$sex      =$_POST['sex'];
$pekerjaan=$_POST['pekerjaan'];
$hobby    =$_POST['hobby'];

echo'Nama          : '; echo$nama     ."<p />";
echo'Alamat        : '; echo$alamat   ."<p />";
echo'Jenis Kelamin : '; echo$sex      ."<p />";
echo'Pekerjaan     : '; echo$pekerjaan."<p />";
echo'Hobby         : '; echo$hobby    ."<p />";
?>
<a href="index.html">Next</a>
<br>
<a href="index16.php">Back</a>
</center>
</body>
</html>